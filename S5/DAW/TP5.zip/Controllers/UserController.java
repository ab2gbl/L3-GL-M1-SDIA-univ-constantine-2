package com.daaw.Controllers;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.daaw.Model.User;
import com.daaw.Model.UserDAO;

@Controller
public class UserController {

	@GetMapping("/addUserForm")
	public String addUserForm(HttpServletRequest request){
		
		if (request.getSession().getAttribute("user") != null) 

			return ("addUserForm");
		else
			return ("login");

	}
	
	@PostMapping("/addUser")
	public String addUser(@ModelAttribute("myuser") User myuser) throws InstantiationException, IllegalAccessException{
			
		UserDAO myDAO = new UserDAO();
		myDAO.addUser(myuser);
		
		return "addUserForm";
		
	}
	
	@PostMapping("/update")
	public String updateUser(@ModelAttribute("myuser") User myuser) throws InstantiationException, IllegalAccessException{
			
		
		
		return "Updated";
		
	}
	
	@PostMapping("/delete")
	public String deleteUser(@ModelAttribute("myuser") User myuser) throws InstantiationException, IllegalAccessException{
			
		
		return "Deleted";
		
	}
	@GetMapping("/usersList")
	public String usersList(HttpServletRequest request,Model model) throws InstantiationException, IllegalAccessException{
		
		UserDAO myDAO;
		if (request.getSession().getAttribute("user") != null) {
			
			myDAO = new UserDAO();
			ArrayList<User> list = new ArrayList<User>();
			list = myDAO.getUsers();
			model.addAttribute("list", list);
			return ("usersList");
		}else
			return ("login");

	}
	

}