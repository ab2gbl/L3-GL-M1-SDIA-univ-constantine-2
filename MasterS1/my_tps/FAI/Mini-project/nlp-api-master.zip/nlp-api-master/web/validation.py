from jsonschema import validate

class Validation():
    @staticmethod
    def validate(json):
        '''Do validation'''
