SENTIMENT_SCHEMA = {
    "type" : "object",
    "properties" : {
     "price" : {"type" : "number"},
     "name" : {"type" : "string"},
    },
}
